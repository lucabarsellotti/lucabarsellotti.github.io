The application is composed by the modules:
- Application.py
- ModelCreator.py
- Preprocessing.py
- TrainingSet.py
- Tweet.py
- TweetScraper.py

"Demo" is used for the demonstration during the presentation.
"chi2" contains the scores obtained by using svm, nb and lr with Chi Square and hop=1 with respect to the number of features.
"chi2_100" contains the scores obtained by using svm, nb and lr with Chi Square and hop=100 with respect to the number of features.
"mutual_information_100" contains the scores obtained by using svm, nb and lr with Chi Square and hop=100 with respect to the number of features.
"Events" contains, for each event:
- Comparison between models based on scores and f-score (comparison.png, lr.csv, nb.csv and svm.csv)
- Event's test set exported in CSV (event.csv)
- Event's test set preprocessed in CSV (preprocessed_event.csv)
- A CSV that contains the merged incremental training set at previous step and the event's test set (incremental_event.csv)
- The best model CLF (model.clf)
- A model generated with svm and 2274 features (incremental_model.clf)
- Scores computed with the model that uses svm and 2274 features (incremental_event_scores.csv)
"MongoDBCollections" contains the files to be imported in MongoDB to get the collections.
"Scores" contains the scores computed on the event test sets by using drift model or incremental models.
"Tweets" contains:
- "Raw" -> exported CSV of replies to Giuseppe Conte
- "Preprocessed" -> preprocessed CSV of replies to Giuseppe Conte
- "DriftPrediction" -> predictions done using default model
- "IncrementalPrediction" -> predictions done using optimal incremental models
- "IncrementalPrediction_old" -> predictions done using incremental models with svm and 2274 features

defaultTS.csv is the exported training set built using replies from 21st February to 14th March to Giuseppe Conte.
preprocessed_defaultTS.csv is the preprocessed version of the default training set and can be used to generate models.
svm_default_model.csv contains the model created by using default training set, svm and 2274 features.

To install the required libraries:
pip install -r requirements.txt