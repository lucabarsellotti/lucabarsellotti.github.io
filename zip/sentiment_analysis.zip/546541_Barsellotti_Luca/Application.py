import tkinter as tk
from datetime import date, datetime
from PIL import ImageTk, Image
import tkinter.ttk as ttk
from tkinter.ttk import Style
from ttkthemes import ThemedStyle
from tkcalendar import *

from ModelCreator import ModelCreator
from TweetScraper import TweetScraper
from TrainingSet import TrainingSet
from Preprocessing import Preprocessing
from Tweet import Tweet
from tkinter import filedialog
import pandas as pd


LARGE_FONT = ("Verdana", 12, "bold")
MEDIUM_FONT = ("Verdana", 10)


class App(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        style = ThemedStyle(self)
        style.set_theme("breeze")
        self.title("Data Mining Project")
        self.resizable(False, False)
        container = tk.Frame(self)

        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (MainMenu, Scrape, Label, Analyze,
                  Export, ExportWithoutLabel, Preprocess,
                  PreprocessWithoutLabel, GenerateModels,
                  StoreModel, EvaluateEvent, MergeTS,
                  CompareDriftIncremental, Predict, PlotPrediction):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
        self.show_frame(MainMenu)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()


class MainMenu(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Main Menu", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=3)

        scrape_button = ttk.Button(self, text="Scrape", command=lambda: controller.show_frame(Scrape), width=30)
        label_button = ttk.Button(self, text="Label", command=lambda: controller.show_frame(Label), width=30)
        analyze_button = ttk.Button(self, text="Analyze", command=lambda: controller.show_frame(Analyze), width=30)
        export_button = ttk.Button(self, text="Export", command=lambda: controller.show_frame(Export), width=30)
        export_without_label_button = ttk.Button(self, text="Export without label", command=lambda: controller.show_frame(ExportWithoutLabel), width=30)
        preprocess_button = ttk.Button(self, text="Preprocess", command=lambda: controller.show_frame(Preprocess), width=30)
        preprocess_without_label_button = ttk.Button(self, text="Preproces without label", command=lambda: controller.show_frame(PreprocessWithoutLabel), width=30)
        generate_models_button = ttk.Button(self, text="Generate models", command=lambda: controller.show_frame(GenerateModels), width=30)
        store_model_button = ttk.Button(self, text="Store model", command=lambda: controller.show_frame(StoreModel), width=30)
        evaluate_event_button = ttk.Button(self, text="Evaluate event", command=lambda: controller.show_frame(EvaluateEvent), width=30)
        mergeTS_button = ttk.Button(self, text="Merge TS", command=lambda: controller.show_frame(MergeTS), width=30)
        predict_button = ttk.Button(self, text="Predict", command=lambda: controller.show_frame(Predict), width=30)
        plot_prediction_button = ttk.Button(self, text="Plot prediction", command=lambda: controller.show_frame(PlotPrediction), width=30)
        compare_drift_incremental_button = ttk.Button(self, text="Compare drift incremental", command=lambda: controller.show_frame(CompareDriftIncremental), width=30)

        scrape_button.grid(row=1, column=0, sticky=tk.W+tk.E)
        label_button.grid(row=1, column=1, sticky=tk.W+tk.E)
        analyze_button.grid(row=1, column=2, sticky=tk.W+tk.E)
        export_button.grid(row=2, column=0, sticky=tk.W+tk.E)
        export_without_label_button.grid(row=2, column=1, sticky=tk.W+tk.E)
        preprocess_button.grid(row=2, column=2, sticky=tk.W+tk.E)
        preprocess_without_label_button.grid(row=3, column=0, sticky=tk.W+tk.E)
        generate_models_button.grid(row=3, column=1, sticky=tk.W+tk.E)
        store_model_button.grid(row=3, column=2, sticky=tk.W+tk.E)
        evaluate_event_button.grid(row=4, column=0, sticky=tk.W+tk.E)
        mergeTS_button.grid(row=4, column=1, sticky=tk.W+tk.E)
        predict_button.grid(row=4, column=2, sticky=tk.W+tk.E)
        plot_prediction_button.grid(row=5, column=0, sticky=tk.W+tk.E)
        compare_drift_incremental_button.grid(row=5, column=1, sticky=tk.W + tk.E)

class Scrape(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Scrape", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        tweet_id_label = ttk.Label(self, text="Tweet ID:")
        tweet_id_entry = ttk.Entry(self)
        since_date_label = ttk.Label(self, text="Since (date, YYYY-MM-DD):")
        since_date_entry = ttk.Entry(self)
        since_time_label = ttk.Label(self, text="Since (time, HH:MM:SS):")
        since_time_entry = ttk.Entry(self)
        username_label = ttk.Label(self, text="Username:")
        username_entry = ttk.Entry(self)
        description_label = ttk.Label(self, text="Description:")
        description_entry = ttk.Entry(self)
        until_date_label = ttk.Label(self, text="Until (date, YYYY-MM-DD):")
        until_date_entry = ttk.Entry(self)
        until_time_label = ttk.Label(self, text="Until (time, HH:MM:SS):")
        until_time_entry = ttk.Entry(self)
        def scrape():
            tweet_scraper = TweetScraper()
            since = since_date_entry.get() + " " + since_time_entry.get()
            until = until_date_entry.get() + " " + until_time_entry.get()
            tweet_list = tweet_scraper.scrape(tweet_id_entry.get(), username_entry.get(), since, until)
            tweet_scraper.store_to_tweet_collection(tweet_id_entry.get(), since_date_entry.get(),
                                                    since_time_entry.get(), username_entry.get(), description_entry.get(), tweet_list)
        start_button = ttk.Button(self, text="Start", command=lambda: scrape())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        tweet_id_label.grid(row=1, column=0, sticky=tk.W+tk.E)
        tweet_id_entry.grid(row=1, column=1, sticky=tk.W+tk.E)
        since_date_label.grid(row=2, column=0, sticky=tk.W+tk.E)
        since_date_entry.grid(row=2, column=1, sticky=tk.W+tk.E)
        since_time_label.grid(row=3, column=0, sticky=tk.W+tk.E)
        since_time_entry.grid(row=3, column=1, sticky=tk.W+tk.E)
        username_label.grid(row=4, column=0, sticky=tk.W+tk.E)
        username_entry.grid(row=4, column=1, sticky=tk.W+tk.E)
        description_label.grid(row=5, column=0, sticky=tk.W+tk.E)
        description_entry.grid(row=5, column=1, sticky=tk.W+tk.E)
        until_date_label.grid(row=6, column=0, sticky=tk.W+tk.E)
        until_date_entry.grid(row=6, column=1, sticky=tk.W+tk.E)
        until_time_label.grid(row=7, column=0, sticky=tk.W+tk.E)
        until_time_entry.grid(row=7, column=1, sticky=tk.W+tk.E)
        start_button.grid(row=8, column=0, sticky=tk.W+tk.E)
        main_menu_button.grid(row=8, column=1, sticky=tk.W+tk.E)



class Label(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Label", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        tweet_id_label = ttk.Label(self, text="Tweet ID:")
        tweet_id_entry = ttk.Entry(self)
        training_set_label = ttk.Label(self, text="Training Set Name:")
        training_set_entry = ttk.Entry(self)
        description_label = ttk.Label(self, text="Description:")
        description_entry = ttk.Entry(self)
        def label():
            training_set = TrainingSet(training_set_entry.get(), description_entry.get(), tweet_id_entry.get())
            training_set.label_tweets(controller)
        start_button = ttk.Button(self, text="Start", command=lambda: label())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        tweet_id_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        tweet_id_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        training_set_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        training_set_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        description_label.grid(row=3, column=0, sticky=tk.W + tk.E)
        description_entry.grid(row=3, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=4, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=4, column=1, sticky=tk.W + tk.E)

class Analyze(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Analyze", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        training_set_label = ttk.Label(self, text="Training Set Name:")
        training_set_entry = ttk.Entry(self)
        result_frame = ttk.Frame(self, width=200, height=50)
        result_label = ttk.Label(result_frame, text="")
        def analyze():
            result_label["text"] = TrainingSet.analyze(training_set_entry.get())
        start_button = ttk.Button(self, text="Start", command=lambda: analyze())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        training_set_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        training_set_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        result_frame.grid(row=2, column=0, columnspan=2)
        result_label.pack()
        start_button.grid(row=3, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=3, column=1, sticky=tk.W + tk.E)

class Export(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Export", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_label = ttk.Label(self, text="Output file (CSV):")
        file_entry = ttk.Entry(self)
        training_set_label = ttk.Label(self, text="Training Set Name:")
        training_set_entry = ttk.Entry(self)
        def export():
            TrainingSet.export_to_csv(file_entry.get(), training_set_entry.get())

        start_button = ttk.Button(self, text="Start", command=lambda: export())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        file_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        training_set_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        training_set_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=3, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=3, column=1, sticky=tk.W + tk.E)

class ExportWithoutLabel(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Export without label", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_label = ttk.Label(self, text="Output file (CSV):")
        file_entry = ttk.Entry(self)
        tweet_id_label = ttk.Label(self, text="Tweet ID:")
        tweet_id_entry = ttk.Entry(self)
        def export():
            TrainingSet.export_unlabeled_to_csv(file_entry.get(), tweet_id_entry.get())
        start_button = ttk.Button(self, text="Start", command=lambda: export())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        file_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        tweet_id_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        tweet_id_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=3, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=3, column=1, sticky=tk.W + tk.E)

class Preprocess(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Preprocess", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_input_label = ttk.Label(self, text="Input file (CSV):")
        file_input_entry = ttk.Entry(self)
        file_output_label = ttk.Label(self, text="Output file (CSV):")
        file_output_entry = ttk.Entry(self)
        def preprocess():
            preprocessing = Preprocessing(file_input_entry.get(), file_output_entry.get())
            preprocessing.preprocess()
        start_button = ttk.Button(self, text="Start", command=lambda: preprocess())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        file_input_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_input_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        file_output_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        file_output_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=3, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=3, column=1, sticky=tk.W + tk.E)

class PreprocessWithoutLabel(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Preprocess without label", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_input_label = ttk.Label(self, text="Input file (CSV):")
        file_input_entry = ttk.Entry(self)
        file_output_label = ttk.Label(self, text="Output file (CSV):")
        file_output_entry = ttk.Entry(self)

        def preprocess():
            preprocessing = Preprocessing(file_input_entry.get(), file_output_entry.get())
            preprocessing.preprocess_without_label()

        start_button = ttk.Button(self, text="Start", command=lambda: preprocess())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        file_input_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_input_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        file_output_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        file_output_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=3, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=3, column=1, sticky=tk.W + tk.E)

class GenerateModels(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Generate models", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        num_fold_label = ttk.Label(self, text="Number of folds:")
        num_fold_entry = ttk.Entry(self)
        file_input_label = ttk.Label(self, text="Input file (CSV):")
        file_input_entry = ttk.Entry(self)
        feature_selection_label = ttk.Label(self, text="Feature Selection ('chi2' or 'info'):")
        feature_selection_entry = ttk.Entry(self)
        hop_label = ttk.Label(self, text="Number of hops:")
        hop_entry = ttk.Entry(self)
        folder_label = ttk.Label(self, text="Output score folder:")
        folder_entry = ttk.Entry(self)
        result_frame = ttk.Frame(self, width=200, height=50)
        result_label = ttk.Label(result_frame, text="")
        def generate_models():
            model_creator = ModelCreator()
            model_creator.generate_models(int(num_fold_entry.get()), file_input_entry.get(), feature_selection_entry.get(), int(hop_entry.get()), folder_entry.get())
            result_text = model_creator.draw_fscore_comparison(int(hop_entry.get()), folder_entry.get())
            result_label.config(text=result_text)
        start_button = ttk.Button(self, text="Start", command=lambda: generate_models())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        num_fold_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        num_fold_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        file_input_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        file_input_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        feature_selection_label.grid(row=3, column=0, sticky=tk.W + tk.E)
        feature_selection_entry.grid(row=3, column=1, sticky=tk.W + tk.E)
        hop_label.grid(row=4, column=0, sticky=tk.W + tk.E)
        hop_entry.grid(row=4, column=1, sticky=tk.W + tk.E)
        folder_label.grid(row=5, column=0, sticky=tk.W + tk.E)
        folder_entry.grid(row=5, column=1, sticky=tk.W + tk.E)
        result_frame.grid(row=6, column=0, columnspan=2)
        result_label.pack()
        start_button.grid(row=7, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=7, column=1, sticky=tk.W + tk.E)

class StoreModel(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Store model", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_input_label = ttk.Label(self, text="Input file (CSV):")
        file_input_entry = ttk.Entry(self)
        num_features_label = ttk.Label(self, text="Number of features:")
        num_features_entry = ttk.Entry(self)
        file_output_label = ttk.Label(self, text="Output file (CLF):")
        file_output_entry = ttk.Entry(self)
        algorithm_label = ttk.Label(self, text="Algorithm (svm, nb or lr):")
        algorithm_entry = ttk.Entry(self)
        def store_model():
            model_creator = ModelCreator()
            model_creator.create_model(file_input_entry.get(), int(num_features_entry.get()), file_output_entry.get(), algorithm_entry.get())

        start_button = ttk.Button(self, text="Start", command=lambda: store_model())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        file_input_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_input_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        num_features_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        num_features_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        file_output_label.grid(row=3, column=0, sticky=tk.W + tk.E)
        file_output_entry.grid(row=3, column=1, sticky=tk.W + tk.E)
        algorithm_label.grid(row=4, column=0, sticky=tk.W + tk.E)
        algorithm_entry.grid(row=4, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=5, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=5, column=1, sticky=tk.W + tk.E)

class EvaluateEvent(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Evaluate event", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_model_label = ttk.Label(self, text="Input file model (CLF):")
        file_model_entry = ttk.Entry(self)
        file_event_label = ttk.Label(self, text="Input file event (CSV):")
        file_event_entry = ttk.Entry(self)
        file_output_label = ttk.Label(self, text="Output file (CSV):")
        file_output_entry = ttk.Entry(self)
        def evaluate():
            model_creator = ModelCreator()
            model_creator.evaluate_scoring(file_model_entry.get(), file_event_entry.get(), file_output_entry.get())

        start_button = ttk.Button(self, text="Start", command=lambda: evaluate())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        file_model_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_model_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        file_event_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        file_event_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        file_output_label.grid(row=3, column=0, sticky=tk.W + tk.E)
        file_output_entry.grid(row=3, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=4, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=4, column=1, sticky=tk.W + tk.E)

class MergeTS(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Merge training sets", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_input1_label = ttk.Label(self, text="Input file 1 (CSV):")
        file_input1_entry = ttk.Entry(self)
        file_input2_label = ttk.Label(self, text="Input file 2 (CSV):")
        file_input2_entry = ttk.Entry(self)
        file_output_label = ttk.Label(self, text="Output file (CSV):")
        file_output_entry = ttk.Entry(self)
        def merge():
            model_creator = ModelCreator()
            model_creator.merge_training_set(file_input1_entry.get(), file_input2_entry.get(), file_output_entry.get())

        start_button = ttk.Button(self, text="Start", command=lambda: merge())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        file_input1_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_input1_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        file_input2_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        file_input2_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        file_output_label.grid(row=3, column=0, sticky=tk.W + tk.E)
        file_output_entry.grid(row=3, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=4, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=4, column=1, sticky=tk.W + tk.E)

class CompareDriftIncremental(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Compare Drift and Incremental", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        drift_label = ttk.Label(self, text="Drift scores path:")
        drift_entry = ttk.Entry(self)
        incremental_label = ttk.Label(self, text="Incremental scores path:")
        incremental_entry = ttk.Entry(self)
        def compare():
            model_creator = ModelCreator()
            model_creator.compare_drift_incremental(drift_entry.get(), incremental_entry.get())
        start_button = ttk.Button(self, text="Start", command=lambda: compare())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        drift_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        drift_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        incremental_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        incremental_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=3, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=3, column=1, sticky=tk.W + tk.E)

class Predict(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Predict", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        file_dataset_label = ttk.Label(self, text="Input file dataset (CSV):")
        file_dataset_entry = ttk.Entry(self)
        file_model_label = ttk.Label(self, text="Input file model (CLF):")
        file_model_entry = ttk.Entry(self)
        file_output_label = ttk.Label(self, text="Output file (CSV):")
        file_output_entry = ttk.Entry(self)
        def predict():
            model_creator = ModelCreator()
            model_creator.predict(file_dataset_entry.get(), file_model_entry.get(), file_output_entry.get())

        start_button = ttk.Button(self, text="Start", command=lambda: predict())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))
        file_dataset_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        file_dataset_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        file_model_label.grid(row=2, column=0, sticky=tk.W + tk.E)
        file_model_entry.grid(row=2, column=1, sticky=tk.W + tk.E)
        file_output_label.grid(row=3, column=0, sticky=tk.W + tk.E)
        file_output_entry.grid(row=3, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=4, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=4, column=1, sticky=tk.W + tk.E)

class PlotPrediction(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="PlotPrediction", font=LARGE_FONT)
        label.grid(row=0, column=0, columnspan=2)

        path_label = ttk.Label(self, text="Path:")
        path_entry = ttk.Entry(self)
        def plot_prediction():
            model_creator = ModelCreator()
            model_creator.plot_classification(path_entry.get())

        start_button = ttk.Button(self, text="Start", command=lambda: plot_prediction())
        main_menu_button = ttk.Button(self, text="Main Menu", command=lambda: controller.show_frame(MainMenu))

        path_label.grid(row=1, column=0, sticky=tk.W + tk.E)
        path_entry.grid(row=1, column=1, sticky=tk.W + tk.E)
        start_button.grid(row=2, column=0, sticky=tk.W + tk.E)
        main_menu_button.grid(row=2, column=1, sticky=tk.W + tk.E)

app = App()
app.mainloop()