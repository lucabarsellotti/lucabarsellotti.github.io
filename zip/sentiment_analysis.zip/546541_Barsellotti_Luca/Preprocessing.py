import re
import emoji
import csv
from nltk.stem import SnowballStemmer
import sys


class Preprocessing:
    def __init__(self, file_input, file_output):
        self.input = file_input
        self.output = file_output
        self.tweets_list = []

    #def read_csv: legge il csv e lo mette in una lista
    #def write_csv: scrive il csv a partire dalla lista preprocessata
    #def trasformare le emoji in testo
    #def convertire il testo in lower case
    #def espandare le abbreviazioni
    #def rimuovere # dal testo
    #def rimuovere le menzioni
    #def stop word filtering
    #def stemming

    def read_csv(self):
        #   Il formato delle righe e' <id, datestamp, timestamp, text, label>
        with open(self.input, mode="r", encoding="utf-8") as csv_file:
            reader = csv.reader(csv_file, delimiter=",")
            for row in reader:
                self.tweets_list.append(row)
        return self.tweets_list

    def write_csv(self):
        with open(self.output, mode="w", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['id', 'datestamp', 'timestamp', 'tweet', 'label']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames, quotechar="|")
            for tweet in self.tweets_list:
                writer.writerow({'id': tweet[0],
                                 'datestamp': tweet[1],
                                 'timestamp': tweet[2],
                                 'tweet': tweet[3],
                                 'label': tweet[4]})

    def write_csv_without_label(self):
        with open(self.output, mode="w", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['id', 'datestamp', 'timestamp', 'tweet']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames, quotechar="|")
            for tweet in self.tweets_list:
                writer.writerow({'id': tweet[0],
                                 'datestamp': tweet[1],
                                 'timestamp': tweet[2],
                                 'tweet': tweet[3]})

    def transform_emoji(self):
        for tweet in self.tweets_list:
            tweet[3] = emoji.demojize(tweet[3]).replace("_", "")

    def lowercase(self):
        for tweet in self.tweets_list:
            tweet[3] = tweet[3].lower()

    def expand_abbreviations(self):
        for tweet in self.tweets_list:
            splitted = re.split("\s", tweet[3])
            blank = ""
            for word in splitted:
                with open("abbreviazioni.txt", "r") as csv_file:
                    reader = csv.reader(csv_file, delimiter="=")
                    for row in reader:
                        if word == row[0]:
                            word = row[1]
                if not word.isspace():
                    blank = blank + word + " "
            if not blank.isspace():
                # Remove space at the end of the text
                text = re.sub('\s', '', blank[::-1], 1)
                tweet[3] = text[::-1]

    # Remove #, mentions, special characters and stopwords
    def clean_characters(self):
        # Load the stopword list
        stopword_list = []
        file = open("stopwords.txt", "r")
        line = file.readline()
        while line:
            x = line.split()
            stopword_list.append(x[0])
            line = file.readline()
        file.close()
        for tweet in self.tweets_list:
            splitted = re.split("\s+", tweet[3])
            blank = ""
            for word in splitted:
                if re.match(r'^#', word):
                    word = re.sub("#", "", word)
                if re.match(r'^@', word):
                    word = ""
                if re.match(r'^([\s\d]+)$', word):
                    word = ""
                # word = re.sub('[^0-9a-zA-Z]+', '', word)
                word = re.sub('[^A-Za-z0-9àèìòùé]+', ' ', word)
                if word == "":
                    continue
                for sw in stopword_list:
                    if re.match(" " + sw + " ", " " + word + " "):
                        word = ""
                        break
                if not word.isspace():
                    blank = blank + word + " "
            if not blank.isspace() or blank != "" or blank != " ":
                tweet[3] = re.sub("\s+", " ", blank)

    def stemming(self):
        stemmer = SnowballStemmer("italian")
        for tweet in self.tweets_list:
            splitted = re.split("\s+", tweet[3])
            stemmed = []
            for word in splitted:
                stemmed.append(stemmer.stem(word))
            blank = ''
            for word in stemmed:
                if not word.isspace():
                    blank = blank + word + ' '
            if not blank.isspace() or blank != "" or blank != " ":
                tweet[3] = blank
            text = re.sub('\s+', '', tweet[3][::-1], 1)
            tweet[3] = text[::-1]

    def replace_label_string(self):
        for tweet in self.tweets_list:
            if tweet[4] == "Neutral":
                tweet[4] = "0"
            if tweet[4] == "Favour":
                tweet[4] = "1"
            if tweet[4] == "Contrast":
                tweet[4] = "-1"

    def preprocess(self):
        self.read_csv()
        self.transform_emoji()
        self.lowercase()
        self.expand_abbreviations()
        self.clean_characters()
        self.stemming()
        self.replace_label_string()
        self.write_csv()

    def preprocess_without_label(self):
        self.read_csv()
        self.transform_emoji()
        self.lowercase()
        self.expand_abbreviations()
        self.clean_characters()
        self.stemming()
        self.write_csv_without_label()


if __name__ == '__main__':
    args = sys.argv
    if len(args) == 4 and args[1] == "without_label":
        file_input = args[2]
        file_output = args[3]
        preprocessing = Preprocessing(file_input, file_output)
        preprocessing.preprocess_without_label()
        exit(1)
    if len(args) < 3:
        print("Usage: <input, output>")
    file_input = args[1]
    file_output = args[2]
    preprocessing = Preprocessing(file_input, file_output)
    preprocessing.preprocess()

