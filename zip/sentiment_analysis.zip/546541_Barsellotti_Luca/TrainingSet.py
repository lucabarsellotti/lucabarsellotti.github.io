import pymongo
import sys
import tkinter as tk
import csv


class TrainingSet:

    def __init__(self, training_set_name, description, tweet_id):
        self.MONGO_SERVER = "mongodb://localhost:27017/"
        self.MONGO_DB = "tweetDB"
        self.MONGO_TWEET_COLLECTION = "tweetCollection"
        self.MONGO_TRAINING_SET_COLLECTION = "trainingSetCollection"
        self.client = pymongo.MongoClient(self.MONGO_SERVER)
        self.db = self.client[self.MONGO_DB]
        self.tweet_collection = self.db[self.MONGO_TWEET_COLLECTION]
        self.training_set_collection = self.db[self.MONGO_TRAINING_SET_COLLECTION]
        self.replies_list = []
        self.training_set_document_name = training_set_name
        self.description = description
        self.tweet_id = tweet_id
        self.index = 0
        self.max_index = 0

    def label_tweets(self, root):
        query = {"tweet_id": self.tweet_id}
        docs = self.tweet_collection.find_one(query)
        self.replies_list = docs["replies"]
        self.max_index = len(self.replies_list)
        self.check_training_set()
        self.load_labelling_application(root)

    @staticmethod
    def export_to_csv(file, training_set_name):
        MONGO_SERVER = "mongodb://localhost:27017/"
        MONGO_DB = "tweetDB"
        MONGO_TWEET_COLLECTION = "tweetCollection"
        MONGO_TRAINING_SET_COLLECTION = "trainingSetCollection"
        client = pymongo.MongoClient(MONGO_SERVER)
        db = client[MONGO_DB]
        tweet_collection = db[MONGO_TWEET_COLLECTION]
        training_set_collection = db[MONGO_TRAINING_SET_COLLECTION]
        query = {"name": training_set_name}
        if training_set_collection.count_documents(query) == 0:
            print("Dataset not found")
            exit(0)
        training_set = training_set_collection.find_one(query)
        tweets_list = training_set["tweets"]
        with open(file, mode="w", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['id', 'datestamp', 'timestamp', 'tweet', 'label']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames, quotechar="|")
            writer.writeheader()
            for tweet in tweets_list:
                writer.writerow({'id': tweet["tweet_id"],
                                 'datestamp': tweet["datestamp"],
                                 'timestamp': tweet["timestamp"],
                                 'tweet': tweet["text"].replace('\n', ' ').replace('\r', '').replace(',', ''),
                                 'label': tweet["label"]})

    @staticmethod
    def analyze(name):
        MONGO_SERVER = "mongodb://localhost:27017/"
        MONGO_DB = "tweetDB"
        MONGO_TWEET_COLLECTION = "tweetCollection"
        MONGO_TRAINING_SET_COLLECTION = "trainingSetCollection"
        client = pymongo.MongoClient(MONGO_SERVER)
        db = client[MONGO_DB]
        tweet_collection = db[MONGO_TWEET_COLLECTION]
        training_set_collection = db[MONGO_TRAINING_SET_COLLECTION]
        query = {"name": name}
        tweets_list = training_set_collection.find_one(query)["tweets"]
        neutral = 0
        favour = 0
        contrast = 0
        for tweet in tweets_list:
            if tweet["label"] == "Neutral":
                neutral += 1
            if tweet["label"] == "Favour":
                favour += 1
            if tweet["label"] == "Contrast":
                contrast += 1
        return_string = "Neutral: " + str(neutral) + "\nFavour: " + str(favour) + "\nContrast: " + str(contrast) + "\nTotal: " + str(neutral+favour+contrast)
        print("Neutral: " + str(neutral))
        print("Favour: " + str(favour))
        print("Contrast: " + str(contrast))
        print(("Total: " + str(neutral+favour+contrast)))
        return return_string


    def check_training_set(self):
        query = {"name": self.training_set_document_name}
        if self.training_set_collection.count_documents(query) == 0:
            training_set_document = {"name": self.training_set_document_name, "description": self.description, "tweets": [], "collections": []}
            self.training_set_collection.insert_one(training_set_document)
            return
        docs = self.training_set_collection.find_one(query)
        collections = docs["collections"]
        for collection in collections:
            if collection["tweet_id"] == self.tweet_id:
                self.index = collection["index"]

    def update_index(self):
        query = {"name": self.training_set_document_name, "collections": {"$elemMatch": {"tweet_id": self.tweet_id}}}
        print(str(self.training_set_collection.count_documents(query)))
        if self.training_set_collection.count_documents(query) == 0:
            query_name = {"name": self.training_set_document_name}
            self.training_set_collection.update_one(
                query_name,
                {"$addToSet": {"collections": {"tweet_id": self.tweet_id, "index": self.index}}}
            )
        else:
            self.training_set_collection.update_one(
                query,
                {"$set": {"collections.$.index": self.index}}
            )


#   Crea un container vuoto e chiama la funzione per caricare il frame con il labelling per la prima risposta
    def load_labelling_application(self, root):
        self.root = tk.Toplevel(root)
        self.root.geometry("600x300")
        self.root.title("Labelling Phase")
        self.root.resizable(False, False)
        container = tk.Frame(self.root)
        container.pack(side="top", fill="both", expand=True)
        self.load_tweet_frame(container)
        self.root.mainloop()

#   Crea un frame con il labelling per una determinata risposta
    def load_tweet_frame(self, container):

        def confirm_label(label, container):
            self.insert_row_db(label)
            self.index += 1
            if self.index == self.max_index:
                self.root.destroy()
            self.load_tweet_frame(container)
            frame.destroy()

        def discard(container):
            self.index += 1
            if self.index == self.max_index:
                self.root.destroy()
            self.load_tweet_frame(container)
            frame.destroy()

        def stop():
            self.update_index()
            self.root.destroy()

        frame = tk.Frame(container)
        text_frame = tk.Frame(frame, width=4000, height=400, borderwidth=2, relief=tk.SUNKEN)
        text = tk.Label(text_frame, text=self.replies_list[self.index]["text"], wraplength=500)
        label = tk.StringVar()
        label.set("Neutral")
        neutral_button = tk.Radiobutton(frame, text="Neutral", variable=label, value="Neutral")
        favour_button = tk.Radiobutton(frame, text="In favor", variable=label, value="Favour")
        contrast_button = tk.Radiobutton(frame, text="In contrast", variable=label, value="Contrast")
        confirm_button = tk.Button(frame, text="Confirm", command=lambda: confirm_label(label.get(), container))
        discard_button = tk.Button(frame, text="Discard", command=lambda: discard(container))
        stop_button = tk.Button(frame, text="Stop", command=lambda: stop())

        frame.pack()
        text_frame.pack()
        text.pack()
        neutral_button.pack()
        favour_button.pack()
        contrast_button.pack()
        confirm_button.pack()
        discard_button.pack()
        stop_button.pack()

    def insert_row_db(self, label):
        query = {"name": self.training_set_document_name}
        reply = self.replies_list[self.index]
        self.training_set_collection.update_one(
            query,
            {'$addToSet': {"tweets": {"tweet_id": reply["tweet_id"], "datestamp": reply["datestamp"], "timestamp": reply["timestamp"], "text": reply["text"], "label": label}}}
        )

    @staticmethod
    def export_unlabeled_to_csv(file, tweet_id):
        MONGO_SERVER = "mongodb://localhost:27017/"
        MONGO_DB = "tweetDB"
        MONGO_TWEET_COLLECTION = "tweetCollection"
        MONGO_TRAINING_SET_COLLECTION = "trainingSetCollection"
        client = pymongo.MongoClient(MONGO_SERVER)
        db = client[MONGO_DB]
        tweet_collection = db[MONGO_TWEET_COLLECTION]
        training_set_collection = db[MONGO_TRAINING_SET_COLLECTION]
        query = {"tweet_id": tweet_id}
        if tweet_collection.count_documents(query) == 0:
            print("Dataset not found")
            exit(0)
        dataset = tweet_collection.find_one(query)
        replies_list = dataset["replies"]
        with open(file, mode="w", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['id', 'datestamp', 'timestamp', 'tweet']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames, quotechar="|")
            writer.writeheader()
            for reply in replies_list:
                writer.writerow({'id': reply["tweet_id"],
                                 'datestamp': reply["datestamp"],
                                 'timestamp': reply["timestamp"],
                                 'tweet': reply["text"].replace('\n', ' ').replace('\r', '').replace(',', '')})


if __name__ == "__main__":
    args = sys.argv
    print(args)
    if args[1] == "label":
        #   Gli argomenti sono <operazione, tweet_id, training_set_name, description(opzionale)>
        if len(args) < 4:
            print("Usage: <operazione, tweet_id, training_set_name, description(opzionale)>")
            exit(0)
        tweet_id = args[2]
        training_set_name = args[3]
        if len(args) < 5:
            description = ""
        else:
            description = args[4]
        training_set = TrainingSet(training_set_name, description, tweet_id)
        training_set.label_tweets()
    elif args[1] == "export":
        file = args[2]
        training_set_name = args[3]
        TrainingSet.export_to_csv(file, training_set_name)

    elif args[1] == "analyze":
        training_set_name = args[2]
        TrainingSet.analyze(training_set_name)

    elif args[1] == "export_without_label":
        file = args[2]
        tweet_id = args[3]
        TrainingSet.export_unlabeled_to_csv(file, tweet_id)
