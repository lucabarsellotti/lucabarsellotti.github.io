class Tweet:
    def __init__(self, tweet_id, username, datestamp, timestamp, tweet, label):
        self.id = tweet_id
        self.username = username
        self.datestamp = datestamp
        self.timestamp = timestamp
        self.tweet = tweet.replace('\n', ' ').replace('\t', ' ')
        self.label = label

    def __str__(self):
        return "Id:" + str(self.id) +\
               ", Username: " + self.username +\
               ", Timestamp: " + self.timestamp +\
               ", Datestamo: " + self.datestamp +\
               ", Tweet: " + self.tweet +\
               ", Label: " + self.label
