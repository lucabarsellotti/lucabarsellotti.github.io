import twint
import csv
import pymongo
import sys


class TweetScraper:
    MONGO_SERVER = "mongodb://localhost:27017/"
    MONGO_DB = "tweetDB"
    MONGO_TWEET_COLLECTION = "tweetCollection"
    MONGO_TRAINING_SET_COLLECTION = "trainingSetCollection"
    client = pymongo.MongoClient(MONGO_SERVER)
    db = client[MONGO_DB]
    tweet_collection = db[MONGO_TWEET_COLLECTION]
    training_set_collection = db[MONGO_TRAINING_SET_COLLECTION]

    def __init__(self):
        print("TODO")

    def scrape(self, tweet_id, to, since, until):
        c = twint.Config()
        c.To = to
        c.Lang = "it"
        c.Since = since
        c.Until = until
        c.Hide_output = True
        c.Links = "exclude"
        c.Media = False
        c.Store_object = True
        twint.run.Search(c)
        tweets_list = []
        for scraped_tweet in twint.output.tweets_list:
            if scraped_tweet.conversation_id == tweet_id:
                tweets_list.append(scraped_tweet)
        return tweets_list

    def store_to_tweet_collection(self, tweet_id, datestamp, timestamp, username, description, tweet_list):
        query = {"tweet_id": tweet_id}
        if self.tweet_collection.count_documents(query) == 0:
            element = {"tweet_id": tweet_id, "datestamp": datestamp, "timestamp": timestamp, "username": username, "description": description, "replies": []}
            self.tweet_collection.insert_one(element)
        for reply in tweet_list:
            reply_document = {"tweet_id": reply.id_str, "datestamp": reply.datestamp, "timestamp": reply.timestamp, "text": reply.tweet}
            self.tweet_collection.update_one(
                query,
                {'$addToSet': {"replies": reply_document}}
            )

    def store(self, file, label_tweets_list):
        TweetScraper.store_to_csv(file, label_tweets_list)

    def store_to_csv(self, file, label_tweets_list):
        with open(file.name, mode="a", encoding="utf-8") as csv_file:
            fieldnames = ['id', 'username', 'datestamp', 'timestamp', 'tweet', 'label']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            for label_tweet in label_tweets_list:
                writer.writerow({'id': label_tweet.id,
                                 'username': label_tweet.username,
                                 'datestamp': label_tweet.datestamp,
                                 'timestamp': label_tweet.timestamp,
                                 'tweet': label_tweet.tweet,
                                 'label': label_tweet.label})


if __name__ == "__main__":
    args = sys.argv
    print(args)
#   Gli argomenti sono <tweet_id, datestamp, timestamp, username, descritpion, until>
    tweet_id = args[1]
    datestamp = args[2]
    timestamp = args[3]
    since = datestamp + " " + timestamp
    username = args[4]
    description = args[5]
    until = args[6]
    tweet_scraper = TweetScraper()
    tweet_list = tweet_scraper.scrape(tweet_id, username, since, until)
    tweet_scraper.store_to_tweet_collection(tweet_id, datestamp, timestamp, username, description, tweet_list)
