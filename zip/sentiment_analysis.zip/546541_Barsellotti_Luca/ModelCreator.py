import pandas as pd
import csv
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import mutual_info_regression
from sklearn.feature_selection import chi2
from sklearn import svm
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import make_scorer, accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import cross_validate
import numpy as np
import joblib
import matplotlib.pyplot as plt
import sys
from collections import Counter
import glob
import ntpath


class ModelCreator:
    def __init__(self):
        print("TODO")

    def generate_classifier_csv(self, file_name):
        with open(file_name, mode="w", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['features', 'accuracy',
                          'precision', 'precision_c', 'precision_n', 'precision_f',
                          'recall', 'recall_c', 'recall_n', 'recall_f',
                          'f1_score', 'f1_score_c', 'f1_score_n', 'f1_score_f']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()

    def write_classifier_csv(self, file_name, features, results):
        accuracy = np.round_(np.mean(results['test_accuracy'], dtype=np.float64), 4),
        precision = np.round_(np.mean(results['test_precision'], dtype=np.float64), 4),
        precision_c = np.round_(np.mean(results['test_precision-1'], dtype=np.float64), 4),
        precision_n = np.round_(np.mean(results['test_precision0'], dtype=np.float64), 4),
        precision_f = np.round_(np.mean(results['test_precision1'], dtype=np.float64), 4),
        recall = np.round_(np.mean(results['test_recall'], dtype=np.float64), 4),
        recall_c = np.round_(np.mean(results['test_recall-1'], dtype=np.float64), 4),
        recall_n = np.round_(np.mean(results['test_recall0'], dtype=np.float64), 4),
        recall_f = np.round_(np.mean(results['test_recall1'], dtype=np.float64), 4),
        f1_score = np.round_(np.mean(results['test_f1_score'], dtype=np.float64), 4),
        f1_score_c = np.round_(np.mean(results['test_f1_score-1'], dtype=np.float64), 4),
        f1_score_n = np.round_(np.mean(results['test_f1_score0'], dtype=np.float64), 4),
        f1_score_f = np.round_(np.mean(results['test_f1_score1'], dtype=np.float64), 4),
        with open(file_name, mode="a", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['features', 'accuracy',
                          'precision', 'precision_c', 'precision_n', 'precision_f',
                          'recall', 'recall_c', 'recall_n', 'recall_f',
                          'f1_score', 'f1_score_c', 'f1_score_n', 'f1_score_f']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writerow({
                "features": features,
                "accuracy": accuracy[0],
                "precision": precision[0],
                "precision_c": precision_c[0],
                "precision_n": precision_n[0],
                "precision_f": precision_f[0],
                "recall": recall[0],
                "recall_c": recall_c[0],
                "recall_n": recall_n[0],
                "recall_f": recall_f[0],
                "f1_score": f1_score[0],
                "f1_score_c": f1_score_c[0],
                "f1_score_n": f1_score_n[0],
                "f1_score_f": f1_score_f[0]
            })

    def write_evaluation_csv(self, file_name, results):
        accuracy = np.round_(results['accuracy'], 4)
        precision = np.round_(results['precision'], 4)
        precision_c = np.round_(results['precision-1'], 4)
        precision_n = np.round_(results['precision0'], 4)
        precision_f = np.round_(results['precision1'], 4)
        recall = np.round_(results['recall'], 4)
        recall_c = np.round_(results['recall-1'], 4)
        recall_n = np.round_(results['recall0'], 4)
        recall_f = np.round_(results['recall1'], 4)
        f1_score = np.round_(results['f1_score'], 4)
        f1_score_c = np.round_(results['f1_score-1'], 4)
        f1_score_n = np.round_(results['f1_score0'], 4)
        f1_score_f = np.round_(results['f1_score1'], 4)
        with open(file_name, mode="w", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['accuracy',
                          'precision', 'precision_c', 'precision_n', 'precision_f',
                          'recall', 'recall_c', 'recall_n', 'recall_f',
                          'f1_score', 'f1_score_c', 'f1_score_n', 'f1_score_f']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow({
                "accuracy": accuracy,
                "precision": precision,
                "precision_c": precision_c[0],
                "precision_n": precision_n[0],
                "precision_f": precision_f[0],
                "recall": recall,
                "recall_c": recall_c[0],
                "recall_n": recall_n[0],
                "recall_f": recall_f[0],
                "f1_score": f1_score,
                "f1_score_c": f1_score_c[0],
                "f1_score_n": f1_score_n[0],
                "f1_score_f": f1_score_f[0]
            })

    def generate_models(self, num_fold, input_file, feature_selection, hop, folder):
        training_set = pd.read_csv(input_file)
        data = training_set["tweet"]
        label = training_set["label"]
        self.generate_classifier_csv(folder + "/svm.csv")
        self.generate_classifier_csv(folder + "/nb.csv")
        self.generate_classifier_csv(folder + "/lr.csv")
        count_vectorizer = CountVectorizer()
        data_vectorized = count_vectorizer.fit_transform(data)
        max_features = len(data_vectorized.toarray()[0])
        tfdif = TfidfTransformer()
        data_transformed = tfdif.fit_transform(data_vectorized)
        with joblib.parallel_backend('threading', n_jobs=2):
            for features in range(1, max_features, hop):
                print("Features: " + str(features))
                if feature_selection == "chi2":
                    select_k_best = SelectKBest(chi2, k=features)
                if feature_selection == "info":
                    select_k_best = SelectKBest(mutual_info_regression, k=features)
                text_svm = Pipeline([
                    ('fselect', select_k_best),
                    ('clf', svm.SVC())
                ])
                text_nb = Pipeline([
                    ('fselect', select_k_best),
                    ('clf', MultinomialNB())
                ])
                text_lr = Pipeline([
                    ('fselect', select_k_best),
                    ('clf', LogisticRegression())
                ])

                scoring = {'accuracy': make_scorer(accuracy_score),
                           'precision': make_scorer(precision_score, average="weighted", labels=label, zero_division=True),
                           'precision-1': make_scorer(precision_score, average=None, labels=[-1], zero_division=True),
                           'precision0': make_scorer(precision_score, average=None, labels=[0], zero_division=True),
                           'precision1': make_scorer(precision_score, average=None, labels=[1], zero_division=True),
                           'recall': make_scorer(recall_score, average="weighted", labels=label, zero_division=True),
                           'recall-1': make_scorer(recall_score, average=None, labels=[-1], zero_division=True),
                           'recall0': make_scorer(recall_score, average=None, labels=[0], zero_division=True),
                           'recall1': make_scorer(recall_score, average=None, labels=[1], zero_division=True),
                           'f1_score': make_scorer(f1_score, average="weighted", labels=label, zero_division=True),
                           'f1_score-1': make_scorer(f1_score, average=None, labels=[-1], zero_division=True),
                           'f1_score0': make_scorer(f1_score, average=None, labels=[0], zero_division=True),
                           'f1_score1': make_scorer(f1_score, average=None, labels=[1], zero_division=True)}

                results_svm = cross_validate(estimator=text_svm,
                                             X=data_transformed,
                                             y=label,
                                             cv=num_fold,
                                             scoring=scoring
                                             )
                results_nb = cross_validate(estimator=text_nb,
                                             X=data_transformed,
                                             y=label,
                                             cv=num_fold,
                                             scoring=scoring
                                             )
                results_lr = cross_validate(estimator=text_lr,
                                             X=data_transformed,
                                             y=label,
                                             cv=num_fold,
                                             scoring=scoring
                                             )
                self.write_classifier_csv(folder + "/svm.csv", features, results_svm)
                self.write_classifier_csv(folder + "/nb.csv", features, results_nb)
                self.write_classifier_csv(folder + "/lr.csv", features, results_lr)

    def draw_fscore_comparison(self, hop, folder):
        svm = pd.read_csv(folder + "/svm.csv")
        nb = pd.read_csv(folder + "/nb.csv")
        lr = pd.read_csv(folder+ "/lr.csv")
        svm_features = svm["features"]
        svm_fscore = svm["f1_score"]
        nb_features = nb["features"]
        nb_fscore = nb["f1_score"]
        lr_features = lr["features"]
        lr_fscore = lr["f1_score"]
        plt.plot(svm_features, svm_fscore, label="SVM")
        plt.plot(nb_features, nb_fscore, label="NB")
        plt.plot(lr_features, lr_fscore, label="LR")
        plt.xlabel("Features")
        plt.ylabel("F-Score")
        plt.legend()
        plt.show(block=False)
        svm_best_k = np.argmax(svm_fscore)
        print("Best number of features for SVM:" + str(svm_best_k*hop+1))
        nb_best_k = np.argmax(nb_fscore)
        print("Best number of features for NB:" + str(nb_best_k*hop+1))
        lr_best_k = np.argmax(lr_fscore)
        print("Best number of features for LR:" + str(lr_best_k*hop+1))
        result_string = "Best number of features for SVM:" + str(svm_best_k*hop+1) + \
                        "\nBest number of features for NB:" + str(nb_best_k*hop + 1) + \
                        "\nBest number of features for LR:" + str(lr_best_k*hop+1)
        return result_string

    def create_model(self, input_file, num_features, output_file, algorithm):
        training_set = pd.read_csv(input_file)
        data = training_set["tweet"]
        label = training_set["label"]
        if algorithm == "svm":
            classifier = Pipeline([
                ('vect', CountVectorizer()),
                ('tfidf', TfidfTransformer()),
                ('fselect', SelectKBest(chi2, k=num_features)),
                ('clf', svm.SVC())
            ])
        elif algorithm == "nb":
            classifier = Pipeline([
                ('vect', CountVectorizer()),
                ('tfidf', TfidfTransformer()),
                ('fselect', SelectKBest(chi2, k=num_features)),
                ('clf', MultinomialNB())
            ])
        elif algorithm == "lr":
            classifier = Pipeline([
                ('vect', CountVectorizer()),
                ('tfidf', TfidfTransformer()),
                ('fselect', SelectKBest(chi2, k=num_features)),
                ('clf', LogisticRegression())
            ])
        classifier.fit(data, label)
        joblib.dump(classifier, output_file)

    def predict(self, input_dataset, classifier_file, output_file):
        dataset = pd.read_csv(input_dataset)
        classifier = joblib.load(classifier_file)
        prediction = classifier.predict(dataset["tweet"].values.astype('U'))
        labels = Counter(prediction)
        with open(output_file, mode="w", encoding="utf-8", newline='') as csv_file:
            fieldnames = ['contrast', 'neutral', 'favour']
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow({
                "contrast": labels[-1],
                "neutral": labels[0],
                "favour": labels[1]})


    def merge_training_set(self, csv1, csv2, output_csv):
        training_set1 = pd.read_csv(csv1)
        training_set2 = pd.read_csv(csv2)
        combined_csv = pd.concat([training_set1, training_set2])
        combined_csv.to_csv(output_csv, index=False, encoding="utf-8")


    def evaluate_scoring(self, classifier_file, test_set_file, output_file):
        test_set = pd.read_csv(test_set_file)
        classifier = joblib.load(classifier_file)
        data = test_set["tweet"]
        label = test_set["label"]
        prediction = classifier.predict(data)
        results = {'accuracy': accuracy_score(y_pred=prediction, y_true=label),
                   'precision': precision_score(y_pred=prediction, y_true=label, average="weighted", zero_division=True),
                   'precision-1': precision_score(y_pred=prediction, y_true=label, labels=[-1], average=None, zero_division=True),
                   'precision0': precision_score(y_pred=prediction, y_true=label, labels=[0], average=None, zero_division=True),
                   'precision1': precision_score(y_pred=prediction, y_true=label, labels=[1], average=None, zero_division=True),
                   'recall': recall_score(y_pred=prediction, y_true=label, average="weighted", zero_division=True),
                   'recall-1': recall_score(y_pred=prediction, y_true=label, labels=[-1], average=None, zero_division=True),
                   'recall0': recall_score(y_pred=prediction, y_true=label, labels=[0], average=None, zero_division=True),
                   'recall1': recall_score(y_pred=prediction, y_true=label, labels=[1], average=None, zero_division=True),
                   'f1_score': f1_score(y_pred=prediction, y_true=label, average="weighted", zero_division=True),
                   'f1_score-1': f1_score(y_pred=prediction, y_true=label, labels=[-1], average=None, zero_division=True),
                   'f1_score0': f1_score(y_pred=prediction, y_true=label, labels=[0], average=None, zero_division=True),
                   'f1_score1': f1_score(y_pred=prediction, y_true=label, labels=[1], average=None, zero_division=True)
                   }
        self.write_evaluation_csv(output_file, results)

    def compare_drift_incremental(self, path_drift, path_incremental):
        drift = []
        incremental = []
        events = []
        dir_drift = path_drift + "/*.csv"
        dir_incremental = path_incremental + "/*.csv"
        i = 2
        for file_name in glob.glob(dir_drift):
            csv_file = pd.read_csv(file_name)
            drift.append(float(csv_file["f1_score"][0]))
            events.append(i)
            i += 1
        for file_name in glob.glob(dir_incremental):
            csv_file = pd.read_csv(file_name)
            incremental.append(float(csv_file["f1_score"][0]))
        plt.plot(events, drift, label="Drift")
        plt.plot(events, incremental, label="Incremental")
        plt.xlabel("Events")
        plt.ylabel("F-Score")
        plt.legend()
        plt.show()

    def plot_classification(self, path):
        dir = path + "/*.csv"
        favour = []
        neutral = []
        contrast = []
        dates = []
        for file_name in glob.glob(dir):
            dates.append(ntpath.basename(file_name).replace(".csv", ""))
            csv_file = pd.read_csv(file_name)
            favour_count = float(int(csv_file["favour"][0]))
            neutral_count = float(int(csv_file["neutral"][0]))
            contrast_count = float(int(csv_file["contrast"][0]))
            total_count = favour_count + neutral_count + contrast_count
            favour.append(np.round_(favour_count*100.0/total_count, 1))
            neutral.append(np.round_(neutral_count*100.0/total_count, 1))
            contrast.append(np.round_(contrast_count*100.0/total_count, 1))
        x = np.arange(len(dates))
        fig, ax = plt.subplots()
        width = 0.30
        rects1 = ax.bar(x - width, favour, width, label='Favour')
        rects2 = ax.bar(x, neutral, width, label='Neutral')
        rects3 = ax.bar(x + width, contrast, width, label='Contrast')
        ax.set_ylabel("Prediction")
        ax.set_yticks(np.arange(0, 105, 5))
        ax.set_xlabel("Tweet Dates")
        ax.set_xticks(x)
        ax.set_xticklabels(dates)
        ax.legend()

        def autolabel(rects):
            for rect in rects:
                height = rect.get_height()
                ax.annotate('{}'.format(height),
                            xy=(rect.get_x() + rect.get_width() / 2, height),
                            xytext=(0, 3),  # 3 points vertical offset
                            textcoords="offset points",
                            ha='center', va='bottom')

        autolabel(rects1)
        autolabel(rects2)
        autolabel(rects3)

        fig.tight_layout()
        plt.show()



if __name__ == '__main__':
    args = sys.argv
    if len(args) < 2:
        print("Insert a command")
        exit()
    model_creator = ModelCreator()
    if args[1] == "generate_models":
        if len(args) < 4:
            print("Usage <generate_models, num_fold, preprocessed_training_set_file.csv>")
            exit()
        num_fold = int(args[2]) # 10
        preprocessed_training_set_file = args[3] # preprocessed_defaultTS.csv
        model_creator.generate_models(num_fold, preprocessed_training_set_file)
        model_creator.draw_fscore_comparison()
    if args[1] == "store_model":
        if len(args) < 6:
            print("Usage <store_model, preprocessed_training_set.csv, num_features, output_model.clf, algorithm>")
        input_training_set = args[2] # preprocessed_defaultTS.csv
        num_features = int(args[3]) # 2026
        output_model = args[4] # nb_default_model.clf
        algorithm = args[5] #svm
        model_creator.create_model(input_training_set, num_features, output_model, algorithm)
    if args[1] == "evaluate_event":
        if len(args) < 5:
            print("Usage <evaluate_event, model.clf, input_preprocessed_event.csv, output_event_scores.csv>")
        model = args[2] # nb_default_model.csv
        preprocessed_event = args[3] # Events/Event1/preprocessed_event1.csv
        output_scores = args[4] # Events/Event1/event1_scores.csv
        model_creator.evaluate_scoring(model, preprocessed_event, output_scores)
    if args[1] == "merge":
        if len(args) < 5:
            print("Usage <merge, input_csv1, input_csv2, output_file.csv>")
        csv1 = args[2]
        csv2 = args[3]
        output_csv = args[4]
        model_creator.merge_training_set(csv1, csv2, output_csv)
    if args[1] == "compare":
        model_creator.compare_drift_incremental()
    if args[1] == "predict":
        if len(args) < 5:
            print("Usage <predict, input_dataset, classifier_file, output_file>")
        input_dataset = args[2]
        classifier_file = args[3]
        output_file = args[4]
        model_creator.predict(input_dataset, classifier_file, output_file)
    if args[1] == "plot_prediction":
        if len(args) < 3:
            print("Usage <plot_prediction, path>")
        path = args[2]
        model_creator.plot_classification(path)
