package iot.unipi.it;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.CoAP.Code;
import org.json.JSONArray;
import org.json.JSONObject;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.OptionSet;
import org.eclipse.californium.core.coap.Request;
import org.eclipse.californium.core.coap.Response;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException {
		final PrintStream err = new PrintStream(System.err);
		try {
			System.setErr(new PrintStream("/dev/null"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println("Welcome to NuclearCoAP GUI.");
		while(true) {
			System.out.println("Choose a command:\n"
					+ "1: Show reactors\n"
					+ "2: Get last measurements\n"
					+ "3: Get average value of last measurements\n"
					+ "4: Send cooling request\n");
	        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	        String line = reader.readLine();
			int option = Integer.parseInt(line);
			if (option == 1) {
				showReactors();
			}
			if (option == 2) {
				getLastMeasurements(reader);
			}
			if (option == 3) {
				getAverage(reader);
			}
			if (option == 4) {
				sendCooling(reader);
			}
		}

	}
	
	private static void showReactors() throws InterruptedException {
		CoapClient client = new CoapClient("coap://fd00::1/control");
		Request req = new Request(Code.GET);
		JSONObject json = new JSONObject().put("o", 1);
		req.setPayload(json.toString());
		OptionSet options = new OptionSet().setAccept(MediaTypeRegistry.APPLICATION_JSON);
		req.setOptions(options);
		CoapResponse response = client.advanced(req);
		if (response == null) {
			System.out.println("No response has been received\n");
			return;
		}
		JSONObject jsonResponse = new JSONObject(response.getResponseText());
		JSONArray reactors = jsonResponse.getJSONArray("r");
		for (int i=0; i<reactors.length(); i++) {
			System.out.println("["+(i+1)+"]: "+reactors.getString(i));
		}
	}
	
	private static void getLastMeasurements(BufferedReader reader) throws IOException {
		System.out.println("Insert the name of the reactor:");
		String reactor = reader.readLine();
		System.out.println("Insert the limit of results:");
		int limit = Integer.parseInt(reader.readLine());
		CoapClient client = new CoapClient("coap://fd00::1/control");
		Request req = new Request(Code.GET);
		JSONObject json = new JSONObject().put("o", 2).put("r", reactor).put("l", limit);
		req.setPayload(json.toString());
		OptionSet options = new OptionSet().setAccept(MediaTypeRegistry.APPLICATION_JSON);
		req.setOptions(options);
		CoapResponse response = client.advanced(req);
		if (response == null) {
			System.out.println("No response has been received\n");
			return;
		}
		JSONObject jsonResponse = new JSONObject(response.getResponseText());
		JSONArray measurements = jsonResponse.getJSONArray("m");
		for (int i=0; i<measurements.length(); i++) {
			System.out.println("["+(i+1)+"]: "+measurements.getDouble(i));
		}
		System.out.println("\n");
	}
	
	private static void getAverage(BufferedReader reader) throws IOException{
		System.out.println("Insert the name of the reactor:");
		String reactor = reader.readLine();
		System.out.println("Insert the limit of results:");
		int limit = Integer.parseInt(reader.readLine());
		CoapClient client = new CoapClient("coap://fd00::1/control");
		Request req = new Request(Code.GET);
		JSONObject json = new JSONObject().put("o", 3).put("r", reactor).put("l", limit);
		req.setPayload(json.toString());
		OptionSet options = new OptionSet().setAccept(MediaTypeRegistry.APPLICATION_JSON);
		req.setOptions(options);
		CoapResponse response = client.advanced(req);
		if (response == null) {
			System.out.println("No response has been received\n");
			return;
		}
		JSONObject jsonResponse = new JSONObject(response.getResponseText());
		double average = jsonResponse.getDouble("a");
		System.out.println("Average: "+average+"\n");
	}
	
	private static void sendCooling(BufferedReader reader) throws IOException{
		System.out.println("Insert the name of the reactor:");
		String reactor = reader.readLine();
		System.out.println("Insert the number of seconds:");
		int seconds = Integer.parseInt(reader.readLine());
		CoapClient client = new CoapClient("coap://fd00::1/control");
		Request req = new Request(Code.PUT);
		JSONObject json = new JSONObject().put("r", reactor).put("s", seconds);
		req.setPayload(json.toString());
		OptionSet options = new OptionSet().setAccept(MediaTypeRegistry.APPLICATION_JSON);
		req.setOptions(options);
		CoapResponse response = client.advanced(req);
		if (response == null) {
			System.out.println("No response has been received");
			return;
		}
		System.out.println("Reactor cooled\n");
	}

}
