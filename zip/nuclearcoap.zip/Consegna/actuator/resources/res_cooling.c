#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "coap-engine.h"
#include "dev/leds.h"
#include "sys/log.h"
#define LOG_MODULE "App"
#define LOG_LEVEL LOG_LEVEL_APP

static void res_put_handler(coap_message_t *request, coap_message_t *response, uint8_t *buffer, uint16_t preferred_size, int32_t *offset);

EVENT_RESOURCE(res_cooling,
         "title=\"Cooling: ?seconds=0..\";rt=\"Control\"",
         NULL,
         NULL,
         res_put_handler,
         NULL, 
         NULL);

static struct ctimer ct;
static bool active = 0;
static int remaining_seconds = 0;

void set_green_led_off(void* ptr){
    remaining_seconds = remaining_seconds - 1;
    if (remaining_seconds == 0){
        active = 0;
        leds_off(LEDS_NUM_TO_MASK(LEDS_GREEN));
    }
    else{
        ctimer_reset(&ct);
    }
}

static void
res_put_handler(coap_message_t *request, coap_message_t *response, uint8_t *buffer, uint16_t preferred_size, int32_t *offset)
{
    LOG_INFO_("PUT received\n");
    size_t len = 0;
    const char *text = NULL;
    len = coap_get_query_variable(request, "seconds", &text);
    if (len>0){
        int seconds = atoi(text);
        if (active == 1){
            if (remaining_seconds < seconds){
                remaining_seconds = seconds;
                ctimer_set(&ct, CLOCK_SECOND, set_green_led_off, &seconds);
                LOG_INFO_("New request: cooling for %d seconds\n", seconds);
            }
            if (remaining_seconds >= seconds){
                LOG_INFO_("New requested seconds are lower than remaining\n");
            }
        }
        if (active == 0){
            LOG_INFO_("New request: cooling for %d seconds\n", seconds);
            active = 1;
            remaining_seconds = seconds;
            ctimer_set(&ct, CLOCK_SECOND, set_green_led_off, &seconds);
            leds_on(LEDS_NUM_TO_MASK(LEDS_GREEN));
        }
        coap_set_status_code(response, CHANGED_2_04);
    }
    else{
        coap_set_status_code(response, BAD_REQUEST_4_00);
    }
    
}
