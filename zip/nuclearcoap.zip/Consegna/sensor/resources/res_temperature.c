#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include "coap-engine.h"
#include "sys/log.h"
#define LOG_MODULE "App"
#define LOG_LEVEL LOG_LEVEL_APP

static void res_get_handler(coap_message_t *request, coap_message_t *response, uint8_t *buffer, uint16_t preferred_size, int32_t *offset);
static void res_event_handler(void);

EVENT_RESOURCE(res_temperature,
         "title=\"Temperature\";rt=\"Text\";obs",
         res_get_handler,
         NULL,
         NULL,
         NULL, 
         res_event_handler);

int temperature=0;

static void sense_temperature(){
    temperature=500+rand()%501;
}

static void
res_event_handler(void)
{
    coap_notify_observers(&res_temperature);
}


static void
res_get_handler(coap_message_t *request, coap_message_t *response, uint8_t *buffer, uint16_t preferred_size, int32_t *offset)
{
    sense_temperature();
    coap_set_header_content_format(response, 110); //application/senml+json
    coap_set_payload(response, buffer, snprintf((char *)buffer, preferred_size, "[{\"t\": %ld, \"v\": %d}]", time(NULL), temperature));
    LOG_INFO_("Sending %s\n", (char*)buffer);
}
