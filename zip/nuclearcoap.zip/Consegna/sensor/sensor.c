#include "contiki.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "coap-engine.h"
#include "coap-blocking-api.h"
#include "contiki-net.h"
#include "node-id.h"

#include "sys/log.h"
#include "coap-log.h"
#define LOG_MODULE "App"
#define LOG_LEVEL LOG_LEVEL_APP
#define SERVER_EP "coap://[fd00::1]"

extern coap_resource_t res_temperature;
static struct etimer et;
char *service_urls[2] = { "/register", "/control" };

void client_chunk_handler(coap_message_t *response){
    if(response == NULL) {
        puts("Request timed out\n");
        return;
    }
    LOG_INFO_("Ack received\n");
}

static struct etimer begin;

PROCESS(sensor, "Temperature Sensor");
AUTOSTART_PROCESSES(&sensor);

PROCESS_THREAD(sensor, ev, data)
{
    
    static coap_endpoint_t server_ep;
    
    PROCESS_BEGIN();
    
    coap_activate_resource(&res_temperature, "temperature");
    
    etimer_set(&begin, CLOCK_SECOND*3);
    
    while(1){
        PROCESS_WAIT_EVENT();
        if (ev == PROCESS_EVENT_TIMER && data == &begin)
            break;
    }
    
    static coap_message_t request[1];
    coap_endpoint_parse(SERVER_EP, strlen(SERVER_EP), &server_ep);
    coap_init_message(request, COAP_TYPE_CON, COAP_POST, 0);
    coap_set_header_uri_path(request, service_urls[0]);
    char msg[10];

    if (node_id%2 == 0){
        strcpy(msg, "react1");
    }
    else{
        strcpy(msg, "react2");
    }
    coap_set_payload(request, (uint8_t *)msg, strlen(msg));
    LOG_INFO_("Sending request..\n");
    COAP_BLOCKING_REQUEST(&server_ep, request, client_chunk_handler);
    
    etimer_set(&et, CLOCK_SECOND*3);

    while(1) {
        PROCESS_WAIT_EVENT();
        
        if(ev == PROCESS_EVENT_TIMER && data == &et){
            res_temperature.trigger();
            etimer_set(&et, CLOCK_SECOND*3);
        }
    }

    PROCESS_END();
}
