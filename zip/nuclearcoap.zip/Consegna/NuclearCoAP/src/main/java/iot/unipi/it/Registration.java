package iot.unipi.it;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapObserveRelation;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.Response;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Registration extends CoapResource {
	
	private HashMap<String, List<String>> actuators;
	
	public Registration(String name, HashMap<String, List<String>> actuators) {
		super(name);
		this.actuators = actuators;
	}
	
	
	@Override
	public void handlePOST(CoapExchange exchange) {
		System.out.println("POST request received from" + exchange.getSourceAddress().toString());
		exchange.respond(ResponseCode.CREATED);
		final String reactorName = exchange.getRequestText();
		System.out.println(reactorName);
		CoapClient client = new CoapClient("["+exchange.getSourceAddress().toString().substring(1)+"]:5683/temperature");
		CoapObserveRelation relation = client.observe(new CoapHandler() {
			private String reactor = reactorName;
			public void onLoad(CoapResponse response) {
				System.out.println("Observation received containing: " + response.getResponseText() + "in " + reactor);
				if(response.getOptions().getContentFormat() == 110){ //application/senml+json
					JSONArray array = (JSONArray) new JSONTokener(response.getResponseText()).nextValue();
					JSONObject object = array.getJSONObject(0);
					long seconds=object.getLong("t");
					double measure=object.getDouble("v");
					Temperature temperature = new Temperature(seconds*1000, measure, reactor);
					MongoTemperature.insertTemperature(temperature);
				}
			}
			public void onError() {
				System.err.println("Failed");
			}
		});
	}
	
	@Override
	public void handleGET(CoapExchange exchange) {
		System.out.println("GET request received from" + exchange.getSourceAddress().toString());
		String reactorName = exchange.getRequestText();
		System.out.println(reactorName);
		if (!actuators.containsKey(reactorName)) {
			actuators.put(reactorName, new ArrayList<String>());
		}
		actuators.get(reactorName).add(exchange.getSourceAddress().toString().substring(1));
		Response response = new Response(ResponseCode.CONTENT);
		response.setPayload("Registered");
		exchange.respond(response);
	}

}
