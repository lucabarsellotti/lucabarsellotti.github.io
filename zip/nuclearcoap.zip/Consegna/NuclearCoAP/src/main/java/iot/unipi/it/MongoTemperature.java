package iot.unipi.it;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;

public class MongoTemperature {
	static MongoConnector connector;
	
	static public void setMongoConnector(MongoConnector c) {
		connector = c;
	}
	
	static public void insertTemperature(Temperature temperature) {
		//MongoConnector connector = new MongoConnector();
		MongoCollection<Document> collection = connector.getDatabase().getCollection(temperature.getReactor());
		Document document = new Document("date", new Date(temperature.getDate())).append("value", temperature.getMeasure());
		collection.insertOne(document);
		//connector.close();
	}
	
	static public void checkTemperature(HashMap<String, List<String>> actuators) {
		//MongoConnector connector = new MongoConnector();
		MongoDatabase database = connector.getDatabase();
		MongoIterable<String> collections = database.listCollectionNames();
		for (String collectionName: collections) {
			MongoCollection<Document> collection = database.getCollection(collectionName);
			Bson condition = new Document("$eq", new Date(System.currentTimeMillis()/1000*1000-1000));
			Bson filter = new Document("date", condition);
			MongoCursor<Document> cursor = collection.find(filter).iterator();
			int count = 0;
			double sum = 0;
			try {
			    while (cursor.hasNext()) {
			    	JSONObject json = new JSONObject(cursor.next().toJson());
			    	count++;
			    	sum+=json.getDouble("value");
			    }
			} finally {
				if (count!=0) {
					System.out.println(sum/count);
					if (sum/count > 850) {
						if (actuators.containsKey(collectionName)) {
							List<String> actuatorList = actuators.get(collectionName);
							for (String actuator: actuatorList) {
								CoapClient client = new CoapClient("["+actuator+"]/cooling?seconds=2");
								System.out.println("Cooling at "+actuator);
								CoapResponse response = client.put("Hello", MediaTypeRegistry.TEXT_PLAIN);
							}
						}
					}
				}
			    cursor.close();
			}
		}
		//connector.close();
	}
	
	static public void sendCooling(HashMap<String, List<String>> actuators, String reactor, int seconds) {
		if (actuators.containsKey(reactor)) {
			List<String> actuatorList = actuators.get(reactor);
			for (String actuator: actuatorList) {
				CoapClient client = new CoapClient("["+actuator+"]/cooling?seconds="+seconds);
				CoapResponse response = client.put("Hello", MediaTypeRegistry.TEXT_PLAIN);
			}
		}
	}
	
	static public List<String> getReactors() {
		List<String> reactors = new ArrayList<String>();
		//MongoConnector connector = new MongoConnector();
		MongoDatabase database = connector.getDatabase();
		MongoIterable<String> collections = database.listCollectionNames();
		for (String collectionName: collections) {
			reactors.add(collectionName);
		}
		//connector.close();
		return reactors;
	}
	
	static public List<Double> getMeasurements(String reactor, int limit) {
		System.out.println("Get measurements called");
		List<Double> measurements = new ArrayList<Double>();
		//MongoConnector connector = new MongoConnector();
		MongoDatabase database = connector.getDatabase();
		MongoCollection<Document> collection = database.getCollection(reactor);
		MongoCursor<Document> cursor = collection.find().skip((int) (collection.countDocuments()-limit)).iterator();
		try {
			while (cursor.hasNext()) {
				Document doc = cursor.next();
				Double value = doc.getDouble("value");
				measurements.add(value);
			}
		} finally {
			cursor.close();
		}
		//connector.close();
		return measurements;
	}
	
	static public double getAverage(String reactor, int limit) {
		double sum = 0;
		int count = 0;
		//MongoConnector connector = new MongoConnector();
		MongoDatabase database = connector.getDatabase();
		MongoCollection collection = database.getCollection(reactor);
		MongoCursor<Document> cursor = collection.find().skip((int) (collection.countDocuments()-limit)).iterator();
		try {
			while (cursor.hasNext()) {
				Document doc = cursor.next();
				Double value = doc.getDouble("value");
				sum += value;
				count++;
			}
		} finally {
			cursor.close();
		}
		//connector.close();
		return sum/count;
	}
}
