package iot.unipi.it;

import java.util.HashMap;
import java.util.List;

import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.californium.core.coap.Response;
import org.eclipse.californium.core.coap.CoAP.ResponseCode;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.json.JSONArray;
import org.json.JSONObject;

public class Control extends CoapResource{
	
	private HashMap<String, List<String>> actuators;
	
	public Control(String name, HashMap<String, List<String>> actuators) {
		super(name);
		this.actuators = actuators;
	}
	
	@Override
	public void handleGET(CoapExchange exchange) {
		System.out.println("GET request received from" + exchange.getSourceAddress().toString());
		if(exchange.getRequestOptions().getAccept() == MediaTypeRegistry.APPLICATION_JSON) {
			JSONObject json = new JSONObject(exchange.getRequestText());
			JSONObject jsonResponse = new JSONObject();
			int operation = json.getInt("o");
			if (operation == 1) { //show reactors
				List<String> reactors = MongoTemperature.getReactors();
				JSONArray jsonArray = new JSONArray();
				for (String reactor: reactors) {
					jsonArray.put(reactor);
				}
				jsonResponse.put("r", jsonArray);
			}
			if (operation == 2) { //show last
				String reactor = json.getString("r");
				int limit = json.getInt("l");
				System.out.println(json);
				List<Double> measurements = MongoTemperature.getMeasurements(reactor, limit);
				JSONArray jsonArray = new JSONArray();
				for (double measurement: measurements) {
					jsonArray.put(measurement);
				}
				jsonResponse.put("m", jsonArray);
				System.out.println(jsonResponse.toString());
			}
			if (operation == 3) { //show average
				String reactor = json.getString("r");
				int limit = json.getInt("l");
				double average = MongoTemperature.getAverage(reactor, limit);
				jsonResponse.put("a", average);
			}
			Response response = new Response(ResponseCode.CONTENT);
			response.setPayload(jsonResponse.toString());
			exchange.respond(response);
		}
	}
	
	@Override
	public void handlePUT(CoapExchange exchange) {
		System.out.println("PUT request received from" + exchange.getSourceAddress().toString());
		Response response = new Response(ResponseCode.VALID);
		exchange.respond(response);
		if(exchange.getRequestOptions().getAccept() == MediaTypeRegistry.APPLICATION_JSON) {
			JSONObject json = new JSONObject(exchange.getRequestText());
			int seconds = json.getInt("s");
			String reactor = json.getString("r");
			MongoTemperature.sendCooling(actuators, reactor, seconds);
		}
	}
}
