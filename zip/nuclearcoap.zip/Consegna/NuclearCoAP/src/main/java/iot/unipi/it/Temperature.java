package iot.unipi.it;

import java.util.Date;

public class Temperature {
	private long date;
	private double measure;
	private String reactor;
	
	public Temperature (long date, double measure, String reactor) {
		this.date=date;
		this.measure=measure;
		this.reactor=reactor;
	}
	
	public void setDate(long date) {
		this.date=date;
	}
	
	public void setMeasure(double measure) {
		this.measure=measure;
	}
	
	public void setReactor(String reactor) {
		this.reactor=reactor;
	}
	
	public long getDate() {
		return date;
	}
	
	public double getMeasure() {
		return measure;
	}
	
	public String getReactor() {
		return reactor;
	}
}
