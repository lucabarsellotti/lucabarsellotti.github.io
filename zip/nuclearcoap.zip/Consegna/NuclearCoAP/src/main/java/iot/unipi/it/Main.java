package iot.unipi.it;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.eclipse.californium.core.CoapServer;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		final PrintStream err = new PrintStream(System.err);
		try {
			System.setErr(new PrintStream("/dev/null"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		MongoConnector connector = new MongoConnector();
		MongoTemperature.setMongoConnector(connector);
		CoapServer server = new CoapServer();
		HashMap<String, List<String>> actuators = new HashMap<String, List<String>>();
		Registration registration = new Registration("register", actuators);
		Control control = new Control("control", actuators);
		server.add(registration, control);
		server.start();
		MongoThread thread = new MongoThread(1000, actuators);
		thread.start();
		System.setErr(err);
	}
}
