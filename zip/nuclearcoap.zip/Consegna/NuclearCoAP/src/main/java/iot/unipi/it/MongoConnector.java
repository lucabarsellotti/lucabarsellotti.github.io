package iot.unipi.it;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class MongoConnector {
	
	private String connectionString = "mongodb://localhost:2717";
	private String databaseName = "NuclearCoAPdb";
	private MongoClient mongoClient;
	private MongoDatabase database;
	
	public MongoConnector() {
		mongoClient = MongoClients.create(connectionString);
		database = mongoClient.getDatabase(databaseName);
	}
	
	public MongoDatabase getDatabase() {
		return database;
	}
	
	public void close() {
		mongoClient.close();
	}
}
