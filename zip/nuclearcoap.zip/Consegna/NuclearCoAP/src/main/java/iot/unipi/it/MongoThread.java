package iot.unipi.it;

import java.util.HashMap;
import java.util.List;

public class MongoThread extends Thread{
	private int delay;
	private HashMap<String, List<String>> actuators;
	public MongoThread(int delay, HashMap<String, List<String>> actuators) {
		this.delay = delay;
		this.actuators = actuators;
	}
	public void run() {
		try {
			while(true) {
				Thread.sleep(delay);
				MongoTemperature.checkTemperature(actuators);
			}
		} catch (InterruptedException ie) {
			return;
		}
	}
}
